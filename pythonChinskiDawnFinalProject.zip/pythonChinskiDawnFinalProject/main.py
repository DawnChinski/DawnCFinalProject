from breezypythongui import EasyFrame #This gives all of the code function to make the window
from tkinter import PhotoImage #Imported from tkinter so it can load photos
import random #allows me to use random generation
momsHair = "black" #defined so I can use for later, also allows for a default, allowing it to be impossible for an error to occur.
dadsHair = "black"
momsEyes = "brown"
dadsEyes = "brown"
momsEars = "attached"
dadsEars = "attached"
class geneGenerator(EasyFrame): #creates window
    def __init__(self): #defines variables
        self.momsHair = momsHair #set so that I can use these variables within the class
        self.dadsHair = dadsHair
        self.momsEyes = momsEyes
        self.dadsEyes = dadsEyes
        self.momsEars = momsEars
        self.dadsEars = dadsEars
        EasyFrame.__init__(self) #Initializes EasyFrame to be used
        self.addLabel(text ="Child feature randomizer", row = 0, column = 5, columnspan=2, sticky="NSEW") #Label for the title
        self.addLabel(text="Hair Color", row=2, column=2, columnspan=3, sticky="NSEW") #Label for the hair color section
        self.addLabel(text="Mother", row=3, column=1, columnspan=2, sticky="NSEW") #label for the mother's hair options
        imageOne = self.addLabel(text="", row=1, column=2, sticky="NSEW") #sets where the hair image will be
        self.imageOne = PhotoImage(file = "hair.png") #grabs the hair image
        imageOne["image"] = self.imageOne #sets the hair image where defined earlier
        self.addLabel(text="Father", row=3, column=3, columnspan=2, sticky="NSEW") #label for the father's hair options
        self.addLabel(text="Eye Color", row=2, column=8, columnspan=2, sticky="NSEW") #label for the eye color options
        self.addLabel(text="Mother", row=3, column=7, columnspan=2, sticky="NSEW")#label for the mother's eye color options
        imageTwo = self.addLabel(text="", row=1, column=8, sticky="NSEW") #sets where the eye image will be
        self.imageTwo = PhotoImage(file="eye.png") #grabs the eye image
        imageTwo["image"] = self.imageTwo #sets the eye image where defined earlier
        self.addLabel(text="Father", row=3, column=9, columnspan=2, sticky="NSEW") #label for the father's eye color options
        self.addLabel(text="Earlobes", row=6, column=5, columnspan=2, sticky="NSEW") #label for the earlobe options
        self.addLabel(text="Mother", row=7, column=4, columnspan=2, sticky="NSEW") #label for the mother's earlobe options
        imageThree = self.addLabel(text="", row=5, column=5, sticky="NSEW") #sets where the ear image will be
        self.imageThree = PhotoImage(file="ear.png") #grabs the ear image
        imageThree["image"] = self.imageThree #sets the ear image where defined earlier
        self.addLabel(text="Father", row=7, column=6, columnspan=2, sticky="NSEW") #label for the father's earlobe options
        self.addButton(text="Black", row=4, column=1, columnspan=2, state="disabled", command = self.setMHairBk) #Button for mother black hair, disabled at the start as that's what it's set to, sets mother's hair to black
        self.addButton(text="Brown", row=5, column=1, columnspan=2, state="active", command = self.setMHairBr) #Button for mother brown hair, sets mother's hair to brown
        self.addButton(text="Blonde", row=6, column=1, columnspan=2, state="active", command = self.setMHairBl) #Button for mother blonde hair, sets mother's hair to blonde
        self.addButton(text="Black", row=4, column=3, columnspan=2, state="disabled", command = self.setFHairBk) #Button for father black hair, sets father's hair to black, disabled at the start as that's what it's set to
        self.addButton(text="Brown", row=5, column=3, columnspan=2, state="active", command = self.setFHairBr) #Button for father brown hair, sets father's brown to black
        self.addButton(text="Blonde", row=6, column=3, columnspan=2, state="active", command = self.setFHairBl) #Button for father blonde hair, sets father's blonde to black
        self.addButton(text="Brown", row=4, column=7, columnspan=2, state="disabled", command = self.setMEyeBr) #Button for mother brown eyes, sets mother's eyes to brown, disabled at the start as that's what it's set to
        self.addButton(text="Green", row=5, column=7, columnspan=2, state="active", command = self.setMEyeGr) #Button for mother green eyes, sets mother's eyes to green
        self.addButton(text="Blue", row=6, column=7, columnspan=2, state="active", command = self.setMEyeBl) #Button for mother blue eyes, sets mother's eyes to blue
        self.addButton(text="Brown", row=4, column=9, columnspan=2, state="disabled", command = self.setFEyeBr) #Button for father brown eyes, sets father's eyes to brown, disabled at the start as that's what it's set to
        self.addButton(text="Green", row=5, column=9, columnspan=2, state="active", command = self.setFEyeGr) #Button for father green eyes, sets father's eyes to green
        self.addButton(text="Blue", row=6, column=9, columnspan=2, state="active", command = self.setFEyeBl) #Button for father blue eyes, sets father's eyes to blue
        self.addButton(text="Attached", row=8, column=4, columnspan=2, state="disabled", command = self.setMEarsA) #Button for mother attached earlobes, sets mother's earlobes to attached, disabled at the start as that's what it's set to
        self.addButton(text="Detached", row=9, column=4, columnspan=2, state="active", command = self.setMEarsD) #Button for mother detatched earlobes, sets mother's earlobes to detached
        self.addButton(text="Attached", row=8, column=6, columnspan=2, state="disabled", command = self.setFEarsA) #Button for father attached earlobes, sets father's earlobes to attached, disabled at the start as that's what it's set to
        self.addButton(text="Detached", row=9, column=6, columnspan=2, state="active", command = self.setFEarsD) #Button for father detatched earlobes, sets father's earlobes to detached
        self.addButton(text="Randomize", row=12, column=5, columnspan=2, state="active",command=self.calculate) #Calculates, randomizes, & displays the result of the child
        self.clearBtn = self.addButton(text="Close", row=0, column=10, command = self.exit) #exits the program
    def setMHairBk(self): #Mother black hair button, disables the button to show it's selected
        self.momsHair = "black"
        self.addButton(text="Black", row=4, column=1, columnspan=2, state="disabled", command = self.setMHairBk)
        self.addButton(text="Brown", row=5, column=1, columnspan=2, state="active", command = self.setMHairBr)
        self.addButton(text="Blonde", row=6, column=1, columnspan=2, state="active", command = self.setMHairBl)
    def setMHairBr(self): #Mother brown hair button, disables the button to show it's selected
        self.momsHair = "brown"
        self.addButton(text="Black", row=4, column=1, columnspan=2, state="active", command = self.setMHairBk)
        self.addButton(text="Brown", row=5, column=1, columnspan=2, state="disabled", command = self.setMHairBr)
        self.addButton(text="Blonde", row=6, column=1, columnspan=2, state="active", command = self.setMHairBl)
    def setMHairBl(self): #Mother blonde hair button, disables the button to show it's selected
        self.momsHair = "blonde"
        self.addButton(text="Black", row=4, column=1, columnspan=2, state="active", command = self.setMHairBk)
        self.addButton(text="Brown", row=5, column=1, columnspan=2, state="active", command = self.setMHairBr)
        self.addButton(text="Blonde", row=6, column=1, columnspan=2, state="disabled", command = self.setMHairBl)
    def setFHairBk(self): #Father black hair button, disables the button to show it's selected
        self.dadsHair = "black"
        self.addButton(text="Black", row=4, column=3, columnspan=2, state="disabled", command = self.setFHairBk)
        self.addButton(text="Brown", row=5, column=3, columnspan=2, state="active", command = self.setFHairBr)
        self.addButton(text="Blonde", row=6, column=3, columnspan=2, state="active", command = self.setFHairBl)
    def setFHairBr(self): #Father brown hair button, disables the button to show it's selected
        self.dadsHair = "brown"
        self.addButton(text="Black", row=4, column=3, columnspan=2, state="active", command = self.setFHairBk)
        self.addButton(text="Brown", row=5, column=3, columnspan=2, state="disabled", command = self.setFHairBr)
        self.addButton(text="Blonde", row=6, column=3, columnspan=2, state="active", command = self.setFHairBl)
    def setFHairBl(self): #Father blonde hair button, disables the button to show it's selected
        self.dadsHair = "blonde"
        self.addButton(text="Black", row=4, column=3, columnspan=2, state="active", command = self.setFHairBk)
        self.addButton(text="Brown", row=5, column=3, columnspan=2, state="active", command = self.setFHairBr)
        self.addButton(text="Blonde", row=6, column=3, columnspan=2, state="disabled", command = self.setFHairBl)
    def setMEyeBr(self): #Mother brown eyes button, disables the button to show it's selected
        self.momsEyes = "brown"
        self.addButton(text="Brown", row=4, column=7, columnspan=2, state="disabled", command = self.setMEyeBr)
        self.addButton(text="Green", row=5, column=7, columnspan=2, state="active", command = self.setMEyeGr)
        self.addButton(text="Blue", row=6, column=7, columnspan=2, state="active", command = self.setMEyeBl)
    def setMEyeGr(self): #mother green eyes button, disables the button to show it's selected
        self.momsEyes = "green"
        self.addButton(text="Brown", row=4, column=7, columnspan=2, state="active", command = self.setMEyeBr)
        self.addButton(text="Green", row=5, column=7, columnspan=2, state="disabled", command = self.setMEyeGr)
        self.addButton(text="Blue", row=6, column=7, columnspan=2, state="active", command = self.setMEyeBl)
    def setMEyeBl(self): #Mother blue eyes button, disables the button to show it's selected
        self.momsEyes = "blue"
        self.addButton(text="Brown", row=4, column=7, columnspan=2, state="active", command = self.setMEyeBr)
        self.addButton(text="Green", row=5, column=7, columnspan=2, state="active", command = self.setMEyeGr)
        self.addButton(text="Blue", row=6, column=7, columnspan=2, state="disabled", command = self.setMEyeBl)
    def setFEyeBr(self): #Father brown eyes button, disables the button to show it's selected
        self.dadsEyes = "brown"
        self.addButton(text="Brown", row=4, column=9, columnspan=2, state="disabled", command = self.setFEyeBr)
        self.addButton(text="Green", row=5, column=9, columnspan=2, state="active", command = self.setFEyeGr)
        self.addButton(text="Blue", row=6, column=9, columnspan=2, state="active", command = self.setFEyeBl)
    def setFEyeGr(self): #father green eyes button, disables the button to show it's selected
        self.dadsEyes = "green"
        self.addButton(text="Brown", row=4, column=9, columnspan=2, state="active", command = self.setFEyeBr)
        self.addButton(text="Green", row=5, column=9, columnspan=2, state="disabled", command = self.setFEyeGr)
        self.addButton(text="Blue", row=6, column=9, columnspan=2, state="active", command = self.setFEyeBl)
    def setFEyeBl(self): #father blue eyes button, disables the button to show it's selected
        self.dadsEyes = "blue"
        self.addButton(text="Brown", row=4, column=9, columnspan=2, state="active", command = self.setFEyeBr)
        self.addButton(text="Green", row=5, column=9, columnspan=2, state="active", command = self.setFEyeGr)
        self.addButton(text="Blue", row=6, column=9, columnspan=2, state="disabled", command = self.setFEyeBl)
    def setMEarsA(self): #mother earlobes attached button, disables the button to show it's selected
        self.momsEars = "attached"
        self.addButton(text="Attached", row=8, column=4, columnspan=2, state="disabled", command = self.setMEarsA)
        self.addButton(text="Detached", row=9, column=4, columnspan=2, state="active", command = self.setMEarsD)
    def setMEarsD(self): #mother earlobes detached button, disables the button to show it's selected
        self.momsEars = "detached"
        self.addButton(text="Attached", row=8, column=4, columnspan=2, state="active", command = self.setMEarsA)
        self.addButton(text="Detached", row=9, column=4, columnspan=2, state="disabled", command = self.setMEarsD)
    def setFEarsA(self): #father earlobes attached button, disables the button to show it's selected
        self.dadsEars = "attached"
        self.addButton(text="Attached", row=8, column=6, columnspan=2, state="disabled", command = self.setFEarsA)
        self.addButton(text="Detached", row=9, column=6, columnspan=2, state="active", command = self.setFEarsD)
    def setFEarsD(self): #father earlobes detached button, disables the button to show it's selected
        self.dadsEars = "detached"
        self.addButton(text="Attached", row=8, column=6, columnspan=2, state="active", command = self.setFEarsA)
        self.addButton(text="Detached", row=9, column=6, columnspan=2, state="disabled", command = self.setFEarsD)
    def exit(self): #exit button
        exit(geneGenerator)
    def calculate(self): #calculate button
        randomSex = random.randint(1,2) #randomly decides between male or female assigned at birth
        if (randomSex == 1):
            childsSex = "male"
        else:
            childsSex = "female"
        randomHair = random.randint(1, 2) #randomly decides between mother or father's hair color
        if (randomHair == 1):
            childsHair = self.momsHair
        else:
            childsHair = self.dadsHair
        randomEyes = random.randint(1, 2) #randomly decides between mother or father's eye color
        if (randomEyes == 1):
            childsEyes = self.momsEyes
        else:
            childsEyes = self.dadsEyes
        randomEars = random.randint(1, 2) #randomly decides between mother or father's earlobes
        if (randomEars == 1):
            childsEars = self.momsEars
        else:
            childsEars = self.dadsEars
        # Adds labels showing the results
        self.addLabel(text="RESULTS:", row=2, column=12, columnspan=2, sticky="NSEW")
        self.addLabel(text=childsSex, row=4, column=12, columnspan=2, sticky="NSEW")
        self.addLabel(text=childsHair + " hair", row=6, column=12, columnspan=2, sticky="NSEW")
        self.addLabel(text=childsEyes + " eyes", row=8, column=12, columnspan=2, sticky="NSEW")
        self.addLabel(text=childsEars + " earlobes", row=10, column=12, columnspan=2, sticky="NSEW")

def main(): #pops window up
    geneGenerator().mainloop()
if __name__ == "__main__":
    main()